
% paths to the datasets , u can adjust these by the datasets ill upload
datasetPaths = { ...
    'C:\Users\Asus\OneDrive\Documents\MATLAB\eeglab2025.0.0\HC-final.set', ...
    'C:\Users\Asus\OneDrive\Documents\MATLAB\eeglab2025.0.0\MCI-final.set', ...
    'C:\Users\Asus\OneDrive\Documents\MATLAB\eeglab2025.0.0\mild-final.set'};

groupLabels  = {'Healthy Control','MCI Control','Mild Control'};   

% Event tagging 
eventTags  = [5 6];
eventNames = {'Rose','Chocolate'};   

epochWindow = [-1 5];       
fsTarget    = 256;          

nICsWanted  = 6;            % Becuase the last subject only has 6 ICs we do 6 for all 

% STFT params 
winLength = 0.85;   
stepSize  = 0.051;  

% Frequency bands 
thetaBand = [ 4  8];
gammaBand = [30 50];


nGroups  = numel(groupLabels);
nEvents  = numel(eventTags);

powTheta = cell(nGroups, nICsWanted, nEvents);   
powGamma = cell(nGroups, nICsWanted, nEvents);

timeAxis = [];      % will be set once during processing

clrGrp   = lines(nGroups);   % distinct colours per group

for g = 1:nGroups

    fprintf('\n>>> Loading %s …\n', groupLabels{g});
    EEG = pop_loadset('filename', datasetPaths{g});


    if ~isempty(fsTarget) && EEG.srate ~= fsTarget
        EEG = pop_resample(EEG, fsTarget);
    end


    nICsAvail = size(EEG.icaweights,1);
    nICsUse   = min(nICsWanted, nICsAvail);
    useICidx  = 1:nICsUse;

  
    for ev = 1:nEvents

        % Epoch 
        EEG_ep = pop_epoch(EEG, {num2str(eventTags(ev))}, epochWindow, ...
                           'epochinfo','yes', 'baseline', []);

       
        if isempty(EEG_ep.icaact)
            EEG_ep = computeICActivations(EEG_ep);
        end

        dataMean = squeeze(mean(EEG_ep.icaact(useICidx,:,:),3));

        % STFT parameters in samples
        winS = round(winLength * EEG_ep.srate);
        hopS = round(stepSize  * EEG_ep.srate);
        nfft = 2^nextpow2(winS);

        
        for ic = 1:nICsUse
            sig = double(dataMean(ic,:));

            
            [S, F, T] = stft(sig, EEG_ep.srate, ...
                             'Window', hamming(winS,'periodic'), ...
                             'OverlapLength', winS-hopS, ...
                             'FFTLength', nfft, ...
                             'FrequencyRange','onesided');
            P = abs(S).^2;   

            
            if isempty(timeAxis)
                timeAxis = T + epochWindow(1);   
            end

            thetaIdx = F>=thetaBand(1) & F<=thetaBand(2);
            gammaIdx = F>=gammaBand(1) & F<=gammaBand(2);

powTheta{g,ic,ev} = mean(P(thetaIdx,:),1);
powGamma{g,ic,ev} = mean(P(gammaIdx,:),1);

        end
    end
end



for ic = 1:nICsWanted
    
    
    figure('Name', sprintf('IC %d – Time-Resolved θ & γ Power (dB)', ic), ...
           'Color','w', 'Position', [100 100 1400 350]);
    
    for ev = 1:nEvents
        for bandID = 1:2            
            
            col = (ev-1)*2 + bandID;          
            subplot(1,4,col); hold on; grid on;
            
            % Plot power traces 
            for g = 1:nGroups
                if bandID == 1
                    plot(timeAxis, powTheta{g,ic,ev}, 'LineWidth',1.4, ...
                         'Color', clrGrp(g,:));
                else
                    plot(timeAxis, powGamma{g,ic,ev}, 'LineWidth',1.4, ...
                         'Color', clrGrp(g,:));
                end
            end
            
            % Axis settings
            xlim([epochWindow(1) epochWindow(2)]);
            xlabel('Time (s)');
            if bandID == 1, ylabel('Power (dB)'); end
            
            if bandID == 1
                bandName = '\theta';
            else
                bandName = '\gamma';
            end
            title(sprintf('%s – %s', bandName, eventNames{ev}), ...
                  'FontWeight','bold', 'FontSize',9);
            
            
            if col == 1
                legend(groupLabels, 'FontSize',8, 'Location','northwest');
            end
        end
    end
    
    
    sgtitle({sprintf('IC %d', ic), ...
             'Time-Resolved \theta (4–8 Hz) & \gamma (30–50 Hz) Power in dB', ...
             'Rose vs Chocolate'}, ...
            'FontWeight','bold');
end


function EEG = computeICActivations(EEG)

nIC  = size(EEG.icaweights,1);
nsmp = size(EEG.data,2);
trl  = size(EEG.data,3);

act = (EEG.icaweights * EEG.icasphere) * ...
      reshape(EEG.data(EEG.icachansind,:,:), numel(EEG.icachansind), []);

EEG.icaact = reshape(act, nIC, nsmp, trl);
end



