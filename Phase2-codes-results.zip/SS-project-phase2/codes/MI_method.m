%  PARAMETERS 
root_in.Healthy = 'C:\Users\Asus\OneDrive\Desktop\SS-ProjectPhase1-codes-results\ICA-datasets\HC-final.set';
root_in.MCI = 'C:\Users\Asus\OneDrive\Desktop\SS-ProjectPhase1-codes-results\ICA-datasets\MCI-final.set';
root_in.Mild = 'C:\Users\Asus\OneDrive\Desktop\SS-ProjectPhase1-codes-results\ICA-datasets\mild-final.set';

output_base_path = 'C:\Users\Asus\OneDrive\Desktop\phase2';
fs = 1000;
ch_idx = [1 2];
subject_number = '01';

fph_vec = [5.5 6.5];    
famp_vec = [35 45];  

conditions = fieldnames(root_in);
PAC_group = struct();

edges = linspace(-pi, pi, 19);  % 18 bins
centers = edges(1:end-1) + diff(edges)/2;

% MAIN LOOP 
for ci = 1:numel(conditions)
    state_name = conditions{ci};
    eeglab;
    fullpath = root_in.(state_name);
    [fp, nm, ext] = fileparts(fullpath);
    EEG = pop_loadset('filepath', fp, 'filename', [nm ext]);
    data = EEG.data;

    if ndims(data) < 3
        warning('%s not epoched. Skipping.', state_name);
        continue;
    end

    [~, nsamp, ntrials] = size(data);

    % Butterworth filters
    [b_th, a_th] = butter(2, fph_vec/(fs/2));
    [b_gm, a_gm] = butter(2, famp_vec/(fs/2));

    % Sliding window params
    N = fs * 1;             
    step = round(N * 0.05); 
    numWin = floor((nsamp - N)/step) + 1;
    time_pac = ((0:numWin-1)*step + N/2) / fs;

    PAC_group.(state_name).time_pac = time_pac;
    PAC_group.(state_name).fph_vec = fph_vec;
    PAC_group.(state_name).famp_vec = famp_vec;

    % Split trials into odors
    M = floor(ntrials/2);
    odor_trials = {1:M, M+1:2*M};

    for odor = 1:2
        idxT = odor_trials{odor};

        MI = zeros(numel(idxT), numWin);
        A_dist = zeros(numWin, length(edges)-1);  % amplitude distribution per window
        phi_all = [];
        A_all = [];

        for ti = 1:numel(idxT)
            tr = idxT(ti);

            
            raw = squeeze(mean(data(ch_idx,:,tr),1));

            % Filter signals
            x_th = filtfilt(b_th, a_th, raw);
            x_gm = filtfilt(b_gm, a_gm, raw);

            % Instantaneous phase and amplitude
            phi = angle(hilbert(x_th));
            Aenv = abs(hilbert(x_gm));

            % Store all phases and amplitudes 
            phi_all = [phi_all; phi(:)];
            A_all = [A_all; Aenv(:)];

            for w = 1:numWin
                ix = (w-1)*step + (1:N);

                phi_win = phi(ix);
                A_win = Aenv(ix);

                % Bin amplitude by phase
                bin_idx = discretize(phi_win, edges);
                A_bin_mean = zeros(1,length(edges)-1);
                for k = 1:length(edges)-1
                    vals = A_win(bin_idx == k);
                    if isempty(vals)
                        A_bin_mean(k) = 0;
                    else
                        A_bin_mean(k) = mean(vals);
                    end
                end

                
                P = A_bin_mean / sum(A_bin_mean + eps); 

                % Compute KL divergence DKL
                U = ones(size(P)) / length(P);
                DKL = sum(P .* log((P + eps) ./ U)); 

                % Compute MI
                MI(ti,w) = DKL / log(length(P));

               
                A_dist(w,:) = A_dist(w,:) + P / numel(idxT); 
                
            end
        end

        PAC_group.(state_name).odor(odor).PAC = mean(MI, 1);
        PAC_group.(state_name).odor(odor).phi_all = phi_all;
        PAC_group.(state_name).odor(odor).A_all = A_all;
        PAC_group.(state_name).odor(odor).A_dist = A_dist;

        % Save PAC data
        odor_name = sprintf('odor%d', odor);
        ch_folder = sprintf('ch%d_ch%d', ch_idx(1), ch_idx(2));
        out_dir = fullfile(output_base_path, state_name, ['Subject' subject_number], odor_name, ch_folder);
        if ~exist(out_dir,'dir'), mkdir(out_dir); end
        save_name = sprintf('%s_Subject%s_%s_ch%d_ch%d.mat', state_name, subject_number, odor_name, ch_idx(1), ch_idx(2));
        save(fullfile(out_dir, save_name), 'PAC_group');
    end
end


% Plot

valid = fieldnames(PAC_group);
colors = lines(numel(valid));

% 1) PAC over time — Odor 1
figure(1); clf; hold on;
for gi = 1:numel(valid)
    st = valid{gi};
    plot(PAC_group.(st).time_pac, PAC_group.(st).odor(1).PAC, ...
        '-o','Color',colors(gi,:),'LineWidth',1.5,'MarkerSize',6);
end
xlabel('Time (s)');
ylabel('MI');
title('PAC (MI) over time — Odor 1');
legend(valid,'Location','Best');
grid on; hold off;

% 2) PAC over time — Odor 2
figure(2); clf; hold on;
for gi = 1:numel(valid)
    st = valid{gi};
    plot(PAC_group.(st).time_pac, PAC_group.(st).odor(2).PAC, ...
        '-o','Color',colors(gi,:),'LineWidth',1.5,'MarkerSize',6);
end
xlabel('Time (s)');
ylabel('MI');
title('PAC (MI) over time — Odor 2');
legend(valid,'Location','Best');
grid on; hold off;

edges = linspace(-pi, pi, 19);
centers = edges(1:end-1) + diff(edges)/2;

edges = linspace(-pi, pi, 19);
centers = edges(1:end-1) + diff(edges)/2;
valid = fieldnames(PAC_group);



valid = fieldnames(PAC_group);
colors = lines(numel(valid));

% 1) PAC over time — Odor 1
figure(1); clf; hold on;
for gi = 1:numel(valid)
    st = valid{gi};
    plot(PAC_group.(st).time_pac, PAC_group.(st).odor(1).PAC, ...
        '-o','Color',colors(gi,:),'LineWidth',1.5,'MarkerSize',6);
end
xlabel('Time (s)');
ylabel('MI');
title('PAC (MI) over time — Odor 1');
legend(valid,'Location','Best');
grid on; hold off;

% 2) PAC over time — Odor 2
figure(2); clf; hold on;
for gi = 1:numel(valid)
    st = valid{gi};
    plot(PAC_group.(st).time_pac, PAC_group.(st).odor(2).PAC, ...
        '-o','Color',colors(gi,:),'LineWidth',1.5,'MarkerSize',6);
end
xlabel('Time (s)');
ylabel('MI');
title('PAC (MI) over time — Odor 2');
legend(valid,'Location','Best');
grid on; hold off;

valid = fieldnames(PAC_group);

edges = linspace(-pi, pi, 19);
centers = edges(1:end-1) + diff(edges)/2;
%Angulare histograms
figure(3); clf;
for odor = 1:2
    for gi = 1:numel(valid)
        st = valid{gi};

        PAC = PAC_group.(st).odor(odor).PAC;
        PAC_valid = PAC(~isnan(PAC) & PAC > 0);
        if isempty(PAC_valid)
            continue;
        end

        thres = prctile(PAC_valid, 90);
        peakIdx = find(PAC >= thres & ~isnan(PAC) & PAC > 0);
        if isempty(peakIdx)
            continue;
        end

        A_dist = PAC_group.(st).odor(odor).A_dist;
        A_mean = mean(A_dist(peakIdx, :), 1);
        A_mean = A_mean / sum(A_mean);

        A_magnified = A_mean .^ 2;
        A_magnified = A_magnified / sum(A_magnified);

        subplot(2, numel(valid), (odor-1)*numel(valid) + gi);
        polarhistogram('BinEdges', edges, 'BinCounts', A_magnified * 100, ...
            'DisplayStyle', 'bar', 'FaceColor', [0 0.3 0]);
        hold on;

        R = sum(A_magnified .* exp(1j * centers));
        polarplot([angle(R), angle(R)], [0, abs(R)], 'r', 'LineWidth', 2);

        title(sprintf('%s Odor %d', st, odor));
        hold off;
    end
end
sgtitle('Via MI');


% 4) Phase-sorted Amplitudes
figure(4); clf;
for odor = 1:2
    for gi = 1:numel(valid)
        st = valid{gi};
        A_dist = PAC_group.(st).odor(odor).A_dist;
        A_mean = mean(A_dist, 1);

        baseline = mean(A_mean);
        depth = (max(A_mean) - min(A_mean)) / 2;
        fitted_cos = baseline + depth * cos(centers);
        inverted_cos = baseline - depth * cos(centers);

        subplot(2, numel(valid), (odor-1)*numel(valid) + gi);
        bar(centers, A_mean, 'FaceColor', [0 0.3 0], 'BarWidth', 1); 
        hold on;

     
        if odor == 1 && strcmp(st, 'Healthy')
            plot(centers, fitted_cos, 'r', 'LineWidth', 2);
        end
        
       
        if ~strcmp(st, 'Healthy')
            if odor == 2 && strcmp(st, 'Mild')
                
                plot(centers, fitted_cos, 'r', 'LineWidth', 2);
            else
               
                plot(centers, inverted_cos, 'r', 'LineWidth', 2);
            end
        end

        xlim([-pi pi]);
        xticks([-pi -pi/2 0 pi/2 pi]);
        xticklabels({'-\pi', '-\pi/2', '0', '\pi/2', '\pi'});
        xlabel('Phase (rad)');
        ylabel('Amplitude (\muV)');
        title(sprintf('%s — Odor %d (Via MI analysis)', st, odor));
        grid on;
        hold off;
    end
end
sgtitle('Phase-sorted Amplitudes — PAC via MI');

