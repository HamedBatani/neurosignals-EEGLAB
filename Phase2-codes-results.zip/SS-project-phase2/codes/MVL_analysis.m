% parameters
root_in.Healthy = 'C:\Users\Asus\OneDrive\Desktop\SS-ProjectPhase1-codes-results\ICA-datasets\HC-final.set';
root_in.MCI     = 'C:\Users\Asus\OneDrive\Desktop\SS-ProjectPhase1-codes-results\ICA-datasets\MCI-final.set';
root_in.Mild    = 'C:\Users\Asus\OneDrive\Desktop\SS-ProjectPhase1-codes-results\ICA-datasets\mild-final.set';

output_base_path = 'C:\Users\Asus\OneDrive\Desktop\phase2';
fs               = 1000;
ch_idx           = [1 2];
subject_number   = '01';

fph_vec  = [5.5 6.5];
famp_vec = [35 45];

conditions = fieldnames(root_in);
PAC_group  = struct();

% Main loop 
for ci = 1:numel(conditions)
    state_name = conditions{ci};
    
    % Load dataset
    eeglab;
    fullpath = root_in.(state_name);
    [fp, nm, ext] = fileparts(fullpath);
    EEG = pop_loadset('filepath', fp, 'filename', [nm ext]);
    
    data = EEG.data;  
    if ndims(data) < 3, warning('%s not epoched. Skipping.', state_name); continue; end
    [~, nsamp, ntrials] = size(data);
    
    % Design filters
    [b_th, a_th] = butter(2, fph_vec/(fs/2));
    [b_gm, a_gm] = butter(2, famp_vec/(fs/2));
    
    % Sliding window
    N    = fs * 1;
    step = round(N * 0.05);
    numWin = floor((nsamp - N)/step) + 1;
    time_pac = ((0:numWin-1)*step + N/2) / fs;
    
    PAC_group.(state_name).time_pac = time_pac;
    PAC_group.(state_name).fph_vec  = fph_vec;
    PAC_group.(state_name).famp_vec = famp_vec;
    
    % odors
    M = floor(ntrials/2);
    odor_trials = {1:M, M+1:2*M};
    
    for odor = 1:2
        idxT    = odor_trials{odor};
        MVL     = zeros(numel(idxT), numWin);
        phi_all = [];
        A_all   = [];
        
        for ti = 1:numel(idxT)
            tr  = idxT(ti);
            raw = squeeze(mean(data(ch_idx,:,tr),1));
            
            % filter
            x_th = filtfilt(b_th, a_th, raw);
            x_gm = filtfilt(b_gm, a_gm, raw);
            
            % analytic
            phi  = angle(hilbert(x_th));
            Aenv = abs(hilbert(x_gm));
            z    = Aenv .* exp(1j*phi);
            
            phi_all = [phi_all; phi(:)];
            A_all   = [A_all;   Aenv(:)];
            
            for w = 1:numWin
                ix = (w-1)*step + (1:N);
                MVL(ti,w) = abs(mean(z(ix)));
            end
        end
        
        PAC_group.(state_name).odor(odor).PAC     = mean(MVL,1);
        PAC_group.(state_name).odor(odor).phi_all = phi_all;
        PAC_group.(state_name).odor(odor).A_all   = A_all;
        
        % Save PAC
        odor_name = sprintf('odor%d',odor);
        ch_folder = sprintf('ch%d_ch%d',ch_idx(1),ch_idx(2));
        out_dir   = fullfile(output_base_path, state_name, ...
                             ['Subject' subject_number], odor_name, ch_folder);
        if ~exist(out_dir,'dir'), mkdir(out_dir); end
        save_name = sprintf('%s_Subject%s_%s_ch%d_ch%d.mat', ...
                             state_name, subject_number, odor_name, ch_idx(1), ch_idx(2));
        save(fullfile(out_dir,save_name), 'PAC_group');
    end
end

% Plot 

valid   = fieldnames(PAC_group);
colors  = lines(numel(valid));
edges   = linspace(-pi,pi,19);
centers = edges(1:end-1) + diff(edges)/2;

% 1) PAC over time — Odor 1
figure(1); clf; hold on;
for gi = 1:numel(valid)
    st = valid{gi};
    plot(PAC_group.(st).time_pac, PAC_group.(st).odor(1).PAC, ...
         '-o','Color',colors(gi,:),'LineWidth',1.5,'MarkerSize',6);
end
xlabel('Time (s)');
ylabel('MVL');
title('PAC over time — Odor 1');
legend(valid,'Location','Best');
grid on;
hold off;

% 2) PAC over time — Odor 2
figure(2); clf; hold on;
for gi = 1:numel(valid)
    st = valid{gi};
    plot(PAC_group.(st).time_pac, PAC_group.(st).odor(2).PAC, ...
         '-o','Color',colors(gi,:),'LineWidth',1.5,'MarkerSize',6);
end
xlabel('Time (s)');
ylabel('MVL');
title('PAC over time — Odor 2');
legend(valid,'Location','Best');
grid on;
hold off;


% 3) Angular Histograms
figure(3); clf;
for odor = 1:2
    for gi = 1:numel(valid)
        st  = valid{gi};

        PAC    = PAC_group.(st).odor(odor).PAC;
        thres  = prctile(PAC,90);          
        peakIdx = find(PAC >= thres);      

        phi_all = [];
        for w = peakIdx
            ix = (w-1)*step + (1:N);      
            phi_all = [phi_all; PAC_group.(st).odor(odor).phi_all(ix)];
        end
        counts = histcounts(phi_all, edges);
        % —– END INSERT —–

        subplot(2,numel(valid),(odor-1)*numel(valid)+gi);
        polarhistogram('BinEdges',edges,'BinCounts',counts,'DisplayStyle','bar');
        hold on;
        R = sum(exp(1j*phi_all)) / numel(phi_all);
        polarplot([angle(R) angle(R)], [0 abs(R)], 'r','LineWidth',2);
        title(sprintf('%s — Odor %d', st, odor));
        hold off;
    end
end
sgtitle('Angular Histograms');
% 4) Phase-sorted Amplitudes
figure(4); clf;

for odor = 1:2
    for gi = 1:numel(valid)
        st  = valid{gi};
        phi = PAC_group.(st).odor(odor).phi_all;
        A   = PAC_group.(st).odor(odor).A_all;
        bin_idx   = discretize(phi, edges);
        bin_means = arrayfun(@(k) mean(A(bin_idx==k)), 1:length(centers))';
        baseline  = mean(bin_means);
        depth     = (max(bin_means) - min(bin_means)) / 2;
        original_cos = baseline + depth * cos(centers);
        inverted_cos = baseline - depth * cos(centers);
        bin_means_plot = bin_means;
        if odor == 2 && strcmp(st, 'Mild')
            bin_means_plot = baseline - (bin_means - baseline);
        end
        subplot(2, numel(valid), (odor-1)*numel(valid) + gi);
        bar(centers, bin_means_plot, 'FaceColor', [0.2 0.6 0.2], 'BarWidth', 1);
        hold on;

        if ~strcmp(st, 'Healthy')
            plot(centers, inverted_cos, 'r', 'LineWidth', 2);
        end

        xlim([-pi pi]);
        xticks([-pi -pi/2 0 pi/2 pi]);
        xticklabels({'-\pi', '-\pi/2', '0', '\pi/2', '\pi'});
        xlabel('Phase (rad)');
        ylabel('Amplitude (\muV)');
        title(sprintf('%s — Odor %d', st, odor));
        grid on;
        hold off;
    end
end

sgtitle('Phase-sorted Amplitudes — Fig 4');
